<!-- <template>
  <div>
    <footer class="dashboard-footer">
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class=" footer-content py-3">
                    <p class="m-0 text-center">2022 &copy; TEQO SOLUTIONS - All Rights Reserved.</p>
                </div>
            </div>
        </div>
        </div>
    </footer>
  </div>
</template>

<script>
export default {
    name:'FooterComponent',
}
</script>

<style scoped>
.dashboard-footer{
    background: var(--navy-blue);
}
.dashboard-footer p{
    color: var(--white);
    font-size: var(--fs-3);
} 
</style> -->